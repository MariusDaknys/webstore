<?php
// Load DB config
require __DIR__ . "/../config/config.php";

try {
    // Connect to MySQL
    $connection = new PDO("mysql:host=$host", $username, $password, $options);
    $connection->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);

    // Check if UserTable database exists
    $stmt = $connection->query("SHOW DATABASES LIKE 'UserTable'");
    $userTableExists = $stmt->fetchColumn();

    if (!$userTableExists) {
        // Create UserTable database
        $connection->exec("CREATE DATABASE UserTable DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;");
        echo "UserTable database created.<br>";

        // Use UserTable and create users table
        $connection->exec("USE UserTable;");
        $sqlUsers = file_get_contents(__DIR__ . "/../data/UserTable.sql");
        $connection->exec($sqlUsers);
        echo "Users table created in UserTable.<br>";
    } else {
        echo "UserTable database already exists.<br>";
    }

    // Check if products database exists
    $stmt = $connection->query("SHOW DATABASES LIKE 'products'");
    $productsDBExists = $stmt->fetchColumn();

    if (!$productsDBExists) {
        // Create products database
        $connection->exec("CREATE DATABASE products DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;");
        echo "Products database created.<br>";

        // Connect to products database
        $productsConnection = new PDO("mysql:host=$host;dbname=products", $username, $password, $options);
        $productsConnection->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);

        // Create products table
        $sqlProducts = file_get_contents(__DIR__ . "/../data/products.sql");
        $productsConnection->exec($sqlProducts);
        echo "Products table created in products database.<br>";
    } else {
        echo "Products database already exists.<br>";
    }

} catch (PDOException $error) {
    // Show connection or SQL error
    echo "Error: " . $error->getMessage();
}
?>

