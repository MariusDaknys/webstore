<footer class="custom-footer bg-black text-light px-5">
    <div class="container-fluid">
        <div class="row py-4">
            <!-- About Us -->
            <div class="col-lg-4 col-sm-6">
                <h5 class="footer-heading pb-3">About Us</h5>
                <p class="footer-text">T-Shirt Store is your go-to place for stylish and comfortable t-shirts.</p>
            </div>

            <!-- Quick Links -->
            <div class="col-lg-2 col-sm-6">
                <h5 class="footer-heading pb-3">Quick Links</h5>
                <ul class="list-unstyled">
                    <li><a href="index.php" class="footer-link">Home</a></li>
                    <li><a href="products.php" class="footer-link">Products</a></li>
                    <li><a href="cart.php" class="footer-link">Cart</a></li>
                    <li><a href="register.php" class="footer-link">Register</a></li>
                    <li><a href="login.php" class="footer-link">Login</a></li>
                    <li><a href="contacts.php" class="footer-link">Contact</a></li>
                </ul>
            </div>

            <!-- Stay Connected -->
            <div class="col-lg-4 col-sm-6">
                <h5 class="footer-heading pb-3">Stay Connected</h5>
                <form class="footer-form">
                    <div class="input-group">
                        <input type="email" class="form-control" placeholder="Enter your email">
                        <button type="submit" class="btn btn-warning text-dark">Subscribe</button>
                    </div>
                </form>
                <ul class="list-inline mt-3">
                    <li class="list-inline-item">
                        <a href="https://www.facebook.com" target="_blank" class="social-icon"><i class="fab fa-facebook fa-2x"></i></a>
                    </li>
                    <li class="list-inline-item">
                        <a href="https://www.instagram.com" target="_blank" class="social-icon"><i class="fab fa-instagram fa-2x"></i></a>
                    </li>
                    <li class="list-inline-item">
                        <a href="https://www.tiktok.com" target="_blank" class="social-icon"><i class="fab fa-tiktok fa-2x"></i></a>
                    </li>
                    <li class="list-inline-item">
                        <a href="https://www.youtube.com" target="_blank" class="social-icon"><i class="fab fa-youtube fa-2x"></i></a>
                    </li>
                </ul>
            </div>
        </div>

        <!-- Copyright -->
        <div class="row">
            <div class="col text-center border-top pt-3">
                <p class="footer-text">&copy; 2025 T-Shirt World. All Rights Reserved.</p>
            </div>
        </div>
    </div>
</footer>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
