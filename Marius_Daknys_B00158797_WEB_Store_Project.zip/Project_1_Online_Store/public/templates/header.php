<?php
// Start session if not already started
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}
require_once __DIR__ . "/../../sessions/functions.php";
// Check if user is logged in
$isLoggedIn = isset($_SESSION['Active']) && $_SESSION['Active'] === true;

// Check if user is admin
$isAdmin = isset($_SESSION['UserType']) && $_SESSION['UserType'] === 'admin';
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>T-Shirt Store</title>

    <!-- CSS & Fonts -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://fonts.googleapis.com/css2?family=Playfair+Display:wght@400;600&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="/Project_1_Online_Store/public/css/styles.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.1/css/all.min.css">
</head>
<body>

<!-- Navbar -->
<nav class="navbar navbar-expand-lg navbar-dark bg-black">
    <div class="container d-flex align-items-center">

        <!-- Logo -->
        <div class="me-auto">
            <?php displayLogo(); ?>
        </div>

        <!-- Mobile menu toggle -->
        <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav">
            <span class="navbar-toggler-icon"></span>
        </button>

        <!-- Navigation links -->
        <div class="collapse navbar-collapse justify-content-center" id="navbarNav">
            <ul class="navbar-nav">
                <li class="nav-item"><a class="nav-link" href="/Project_1_Online_Store/public/index.php">Home</a></li>
                <li class="nav-item"><a class="nav-link" href="/Project_1_Online_Store/public/products.php">Products</a></li>
                <li class="nav-item"><a class="nav-link" href="/Project_1_Online_Store/public/contacts.php">Contacts</a></li>
                <li class="nav-item"><a class="nav-link" href="/Project_1_Online_Store/public/about_us.php">About Us</a></li>
            </ul>

            <!-- Right section -->
            <ul class="navbar-nav ms-auto align-items-center">

                <?php if ($isLoggedIn): ?>
                    <!-- Cart with item count -->
                    <li class="nav-item me-3">
                        <a class="nav-link" href="/Project_1_Online_Store/public/cart.php">
                            Cart <span class="badge bg-warning text-dark"><?= getCartCount(); ?></span>
                        </a>
                    </li>

                    <!-- Show username -->
                    <li class="nav-item me-3">
                        <span class="nav-link text-white"><?= htmlspecialchars($_SESSION['Username']); ?></span>
                    </li>

                    <!-- Admin dropdown -->
                    <?php if ($isAdmin): ?>
                        <li class="nav-item dropdown">
                            <a class="nav-link dropdown-toggle" href="#" id="adminDropdown" role="button" data-bs-toggle="dropdown">
                                Admin Panel
                            </a>
                            <ul class="dropdown-menu dropdown-menu-end">
                                <li><a class="dropdown-item" href="/Project_1_Online_Store/admin/edit_products.php">Edit Products</a></li>
                                <li><a class="dropdown-item" href="/Project_1_Online_Store/admin/add_products.php">Add Products</a></li>
                                <li><a class="dropdown-item" href="/Project_1_Online_Store/admin/edit_users.php">Edit Users</a></li>
                            </ul>
                        </li>
                    <?php endif; ?>

                    <!-- Logout button -->
                    <li class="nav-item">
                        <a class="btn btn-danger nav-btn" href="/Project_1_Online_Store/public/logout.php">Logout</a>
                    </li>

                <?php else: ?>
                    <!-- Show login and register -->
                    <li class="nav-item">
                        <a class="btn btn-warning nav-btn me-2" href="/Project_1_Online_Store/public/login.php">Login</a>
                    </li>
                    <li class="nav-item">
                        <a class="btn btn-warning nav-btn" href="/Project_1_Online_Store/public/register.php">Register</a>
                    </li>
                <?php endif; ?>

            </ul>
        </div>
    </div>
</nav>

<?php
// Get current page name for breadcrumb
$currentPage = basename($_SERVER['PHP_SELF']);
?>

<!-- Breadcrumb navigation -->
<nav aria-label="breadcrumb" class="mt-3">
  <ol class="breadcrumb bg-light p-3 rounded shadow-sm">
    <li class="breadcrumb-item">
      <a href="/Project_1_Online_Store/public/index.php" class="text-dark text-decoration-none">Home</a>
    </li>

    <?php if ($currentPage === 'products.php'): ?>
      <li class="breadcrumb-item active text-secondary">Products</li>
    <?php elseif ($currentPage === 'contacts.php'): ?>
      <li class="breadcrumb-item active text-secondary">Contact</li>
    <?php elseif ($currentPage === 'about_us.php'): ?>
      <li class="breadcrumb-item active text-secondary">About Us</li>
    <?php elseif ($currentPage === 'cart.php'): ?>
      <li class="breadcrumb-item active text-secondary">Cart</li>
    <?php elseif ($currentPage === 'login.php'): ?>
      <li class="breadcrumb-item active text-secondary">Login</li>
    <?php elseif ($currentPage === 'register.php'): ?>
      <li class="breadcrumb-item active text-secondary">Register</li>
    <?php else: ?>
      <!-- Auto format other pages -->
      <li class="breadcrumb-item active text-secondary"><?= ucfirst(str_replace('.php', '', $currentPage)); ?></li>
    <?php endif; ?>
  </ol>
</nav>
