<?php
session_start(); // Ensure session starts before using $_SESSION

// Redirect to login if the user is not authenticated
if (!isset($_SESSION['Active']) || $_SESSION['Active'] !== true) {
    header("location: login.php");
    exit();
}
?>
<?php require_once dirname(__DIR__) . '/public/templates/header.php'; ?>

<!-- About Us Section -->
<section class="py-5 bg-light">
    <div class="container">
        <div class="row align-items-center">
            <!-- Left Side - Image -->
            <div class="col-md-6">
                <img src="/Project_1_Online_Store/public/images/abou_us.jpg" class="img-fluid rounded shadow" alt="About Us">
            </div>

            <!-- Right Side - Text -->
            <div class="col-md-6">
                <h2 class="fw-bold">About Us</h2>
                <p class="text-muted">
                    At <strong>T-Shirt World</strong>, Lorem ipsum dolor sit amet consectetur adipisicing elit. Ad modi fuga in illum obcaecati minus quasi suscipit repellat id perspiciatis.
                </p>
                <h4 class="mt-3 fw-bold">Our Mission</h4>
                <p class="text-muted">
                    Lorem ipsum dolor sit amet consectetur adipisicing elit. Quos molestias neque beatae iusto animi. Numquam, iure perferendis. Sequi, corporis laborum.
                </p>
                <a href="products.php" class="btn btn-warning text-white fw-bold px-4 py-2 mt-3">Explore Our Collection</a>
            </div>
        </div>
    </div>
</section>

<!-- Our Team Section -->
<section class="py-5">
    <div class="container text-center">
        <h2 class="fw-bold">Meet Our Team</h2>
        <p class="text-muted mb-4">Passionate people behind T-Shirt World.</p>
        
        <div class="row">
            <div class="col-md-4">
                <img src="/Project_1_Online_Store/public/images/John.jpg" class="rounded-circle img-fluid mb-3" alt="Founder">
                <h5 class="fw-bold">John Doe</h5>
                <p class="text-muted">Founder & CEO</p>
            </div>
            <div class="col-md-4">
                <img src="/Project_1_Online_Store/public/images/Sarah.jpg" class="rounded-circle img-fluid mb-3" alt="Designer">
                <h5 class="fw-bold">Sarah Smith</h5>
                <p class="text-muted">Lead Designer</p>
            </div>
            <div class="col-md-4">
                <img src="/Project_1_Online_Store/public/images/Michael.jpg" class="rounded-circle img-fluid mb-3" alt="Marketing">
                <h5 class="fw-bold">Michael Lee</h5>
                <p class="text-muted">Marketing Director</p>
            </div>
        </div>
    </div>
</section>

<!-- Testimonials Section -->
<section class="py-5 bg-light">
    <div class="container text-center">
        <h2 class="fw-bold">What Our Customers Say</h2>
        <p class="text-muted mb-4">See why people love our t-shirts.</p>

        <div class="row">
            <div class="col-md-4">
                <div class="p-4 border rounded">
                    <i class="fas fa-quote-left fa-2x text-warning"></i>
                    <p class="mt-3">"Best quality t-shirts! Super soft and stylish. Will buy again!"</p>
                    <h6 class="fw-bold">- Emily R.</h6>
                </div>
            </div>
            <div class="col-md-4">
                <div class="p-4 border rounded">
                    <i class="fas fa-quote-left fa-2x text-warning"></i>
                    <p class="mt-3">"Fast shipping and amazing designs. Highly recommend!"</p>
                    <h6 class="fw-bold">- James K.</h6>
                </div>
            </div>
            <div class="col-md-4">
                <div class="p-4 border rounded">
                    <i class="fas fa-quote-left fa-2x text-warning"></i>
                    <p class="mt-3">"Great fit and super comfortable. My new go-to store!"</p>
                    <h6 class="fw-bold">- Sarah M.</h6>
                </div>
            </div>
        </div>
    </div>
</section>

<!-- Follow Us Section -->
<section class="py-5 text-center">
    <div class="container">
        <h2 class="fw-bold">Stay Connected</h2>
        <p class="text-muted mb-3">Follow us for the latest updates and promotions.</p>
        <div class="d-flex justify-content-center gap-3">
            <a href="https://www.facebook.com" target="_blank"><i class="fab fa-facebook fa-2x text-primary"></i></a>
            <a href="https://www.instagram.com" target="_blank"><i class="fab fa-instagram fa-2x text-danger"></i></a>
            <a href="https://www.tiktok.com" target="_blank"><i class="fab fa-tiktok fa-2x text-dark"></i></a>
            <a href="https://www.youtube.com" target="_blank"><i class="fab fa-youtube fa-2x text-danger"></i></a>
        </div>
    </div>
</section>

<!-- Footer -->
<?php require_once dirname(__DIR__) . '/public/templates/footer.php'; ?>
