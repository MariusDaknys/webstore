<?php
// Include the session class file
require_once __DIR__ . '/../sessions/session.php';

// Check if the session class exists before using it
if (class_exists('session')) {
    // Create a new session object
    $session = new session();
     // Call method to clear and destroy the session
    $session->forgetSession();
} else {
    // Show error if class not exist
    die("Error: Session class not found.");
}
