<?php
// Enable error reporting
error_reporting(E_ALL);
ini_set('display_errors', 1);

// Connect to the database
require_once __DIR__ . "/../sessions/functions.php";
require_once __DIR__ . "/../src/DBconnection.php";

$error = "";
$successMessage = "";

$newUsername = $newEmail = $newPassword = $newAge = $newAddress = $newGender = $newUserType = "";

// Handle form submission
if ($_SERVER["REQUEST_METHOD"] === "POST") {
    // Get and clean form inputs
    $newUsername  = escape($_POST['user_name'] ?? '');
    $newEmail     = escape($_POST['user_email'] ?? '');
    $newPassword  = escape($_POST['user_password'] ?? '');
    $newAge       = escape($_POST['user_age'] ?? '');
    $newAddress   = escape($_POST['user_address'] ?? '');
    $newGender    = escape($_POST['user_gender'] ?? '');
    $newUserType  = escape($_POST['account_type'] ?? '');
    // Validate fields
    if (empty($newUsername) || empty($newEmail) || empty($newPassword) || empty($newAge) || empty($newAddress) || empty($newGender) || empty($newUserType)) {
        $error = " All fields are required.";
    } elseif (strlen($newUsername) < 3) {
        $error = " Username must be at least 3 characters.";
    } elseif (!filter_var($newEmail, FILTER_VALIDATE_EMAIL)) {
        $error = " Invalid email format.";
    } elseif (strlen($newPassword) < 6) {
        $error = " Password must be at least 6 characters.";
    } elseif (!is_numeric($newAge) || $newAge < 1 || $newAge > 120) {
        $error = " Age must be a number between 1 and 120.";
    } elseif (!in_array($newGender, ['male', 'female', 'other'])) {
        $error = " Invalid gender selection.";
    } elseif (!in_array($newUserType, ['customer', 'admin'])) {
        $error = " Invalid user type selection.";
    } else {
        try {
            // Check if email already exists
            $checkStmt = $usersDB->prepare("SELECT id FROM users WHERE email = ?");
            $checkStmt->execute([$newEmail]);

            if ($checkStmt->rowCount() > 0) {
                $error = "Email is already registered. Try another one.";
            } else {
                // Hash the password
                $hashedPassword = password_hash($newPassword, PASSWORD_BCRYPT);

                $stmt = $usersDB->prepare(
                    "INSERT INTO users (username, email, password, age, address, gender, user_type, created_at) 
                     VALUES (?, ?, ?, ?, ?, ?, ?, NOW())"
                );
                $stmt->execute([
                    $newUsername,
                    $newEmail,
                    $hashedPassword,
                    $newAge,
                    $newAddress,
                    $newGender,
                    $newUserType
                ]);

                // Clear form
                $newUsername = $newEmail = $newPassword = $newAge = $newAddress = $newGender = $newUserType = '';
                $successMessage = "Registration successful! <a href='login.php' class='back-link'>Login here</a>";
            }
        } catch (PDOException $e) {
            $error = "Database Error: " . $e->getMessage();
        }
    }
}
?>

<?php require_once dirname(__DIR__) . '/public/templates/header.php'; ?>

<div class="user-registration">
    <div class="container">
        <div class="row justify-content-center">
            <div class="col-md-8 col-lg-6">
                <div class="registration-box">
                    <h2 class="text-center text-highlight">Register Page</h2>

                    <!-- Show error or success message -->
                    <?php if (!empty($error)): ?>
                        <div class="alert alert-danger"><?php echo $error; ?></div>
                    <?php endif; ?>
                    <?php if (!empty($successMessage)): ?>
                        <div class="alert alert-success d-flex justify-content-between align-items-center">
                            <span><?php echo $successMessage; ?></span>
                        </div>
                    <?php endif; ?>

                    <!-- Registration Form -->
                    <form method="post">
                        <div class="mb-3">
                            <label for="user_name">Username</label>
                            <input type="text" name="user_name" id="user_name" class="form-field" value="<?php echo escape($newUsername); ?>" required>
                        </div>
                        <div class="mb-3">
                            <label for="user_email">Email Address</label>
                            <input type="email" name="user_email" id="user_email" class="form-field" value="<?php echo escape($newEmail); ?>" required>
                        </div>
                        <div class="mb-3">
                            <label for="user_password">Password</label>
                            <input type="password" name="user_password" id="user_password" class="form-field" required>
                        </div>
                        <div class="mb-3">
                            <label for="user_age">Age</label>
                            <input type="number" name="user_age" id="user_age" class="form-field" value="<?php echo escape($newAge); ?>" required>
                        </div>
                        <div class="mb-3">
                            <label for="user_address">Address</label>
                            <input type="text" name="user_address" id="user_address" class="form-field" value="<?php echo escape($newAddress); ?>" required>
                        </div>
                        <div class="mb-3">
                            <label for="user_gender">Gender</label>
                            <select name="user_gender" id="user_gender" class="form-field" required>
                                <option value="" disabled>Select Gender</option>
                                <option value="male" <?php echo ($newGender === 'male') ? 'selected' : ''; ?>>Male</option>
                                <option value="female" <?php echo ($newGender === 'female') ? 'selected' : ''; ?>>Female</option>
                                <option value="other" <?php echo ($newGender === 'other') ? 'selected' : ''; ?>>Other</option>
                            </select>
                        </div>
                        <div class="mb-3">
                            <label for="account_type">User Type</label>
                            <select name="account_type" id="account_type" class="form-field" required>
                                <option value="customer" <?php echo ($newUserType === 'customer') ? 'selected' : ''; ?>>Customer</option>
                                <option value="admin" <?php echo ($newUserType === 'admin') ? 'selected' : ''; ?>>Admin</option>
                            </select>
                        </div>
                        <button type="submit" class="submit-btn">Submit</button>
                    </form>

                    <div class="text-center mt-3">
                        <a href="index.php" class="back-link">Back to Home</a>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

<?php require_once dirname(__DIR__) . '/public/templates/footer.php'; ?>
