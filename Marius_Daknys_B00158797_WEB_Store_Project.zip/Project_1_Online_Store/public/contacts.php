<?php
session_start(); // Start session

// Redirect to login if user is not logged in
if (!isset($_SESSION['Active']) || $_SESSION['Active'] !== true) {
    header("location: login.php");
    exit();
}

// Add header template
require_once dirname(__DIR__) . '/public/templates/header.php';
?>

<!-- Contact Section -->
<section class="py-5 bg-light">
    <div class="container">
        <h2 class="text-center fw-bold mb-4">Contact Us</h2>
        <p class="text-center text-muted mb-5">Have questions? Fill out the form below or reach out directly!</p>

        <div class="row g-5 align-items-center flex-md-row-reverse">
            <!-- Contact Form (Right Side now) -->
            <div class="col-md-6">
                <div class="p-4 bg-white shadow rounded">
                    <form action="contact_process.php" method="POST">
                        <!-- Name Field -->
                        <div class="mb-3">
                            <label for="name" class="form-label"><i class="fas fa-user"></i> Your Name</label>
                            <input type="text" class="form-field" id="name" name="name" required>
                        </div>

                        <!-- Email Field -->
                        <div class="mb-3">
                            <label for="email" class="form-label"><i class="fas fa-envelope"></i> Your Email</label>
                            <input type="email" class="form-field" id="email" name="email" required>
                        </div>

                        <!-- Message Field -->
                        <div class="mb-3">
                            <label for="message" class="form-label"><i class="fas fa-comment-alt"></i> Your Message</label>
                            <textarea class="form-field" id="message" name="message" rows="5" required></textarea>
                        </div>

                        <!-- Submit Button -->
                        <div class="text-center">
                            <button type="submit" class="btn btn-warning text-dark fw-bold px-5">
                                <i class="fas fa-paper-plane"></i> Send Message
                            </button>
                        </div>
                    </form>
                </div>
            </div>

            <!-- Contact Info (Left Side now) -->
            <div class="col-md-6">
                <div class="p-4 bg-white shadow rounded h-100">
                    <h4 class="fw-bold mb-3"><i class="fas fa-map-marker-alt"></i> Our Location</h4>
                    <p class="text-muted mb-4">19 Dublin 15, Ireland</p>

                    <h4 class="fw-bold mb-3"><i class="fas fa-phone"></i> Call Us</h4>
                    <p class="text-muted mb-4">+338584545</p>

                    <h4 class="fw-bold mb-3"><i class="fas fa-envelope"></i> Email Us</h4>
                    <p class="text-muted mb-4">support@tshirtworld.com</p>

                    <h4 class="fw-bold mb-3"><i class="fas fa-hashtag"></i> Follow Us</h4>
                    <div class="d-flex gap-3">
                        <a href="https://www.facebook.com" target="_blank"><i class="fab fa-facebook fa-2x text-primary"></i></a>
                        <a href="https://www.instagram.com" target="_blank"><i class="fab fa-instagram fa-2x text-danger"></i></a>
                        <a href="https://www.tiktok.com" target="_blank"><i class="fab fa-tiktok fa-2x text-dark"></i></a>
                        <a href="https://www.youtube.com" target="_blank"><i class="fab fa-youtube fa-2x text-danger"></i></a>
                    </div>
                </div>
            </div>
        </div>
    </div>
</section>

<!-- Google Map Section -->
<section class="py-5">
    <div class="container">
        <h4 class="text-center fw-bold mb-4"><i class="fas fa-map-marked-alt"></i> Find Us on Google Maps</h4>
        <div class="d-flex justify-content-center">
            <iframe 
                src="https://www.google.com/maps/embed?pb=..." 
                width="100%" height="400" style="border:0; border-radius: 10px;" allowfullscreen="" loading="lazy">
            </iframe>
        </div>
    </div>
</section>
<!-- Add footer template -->
<?php require_once dirname(__DIR__) . '/public/templates/footer.php'; ?>
