<?php
session_start(); // Start the session to access session data

// Redirect the user to login page if not logged in
if (!isset($_SESSION['Active']) || $_SESSION['Active'] !== true) {
    header("location: login.php");
    exit();
}

// Include the database connection file
require_once __DIR__ . "/../src/DBconnection.php";

try {
    // Get all products from the database, newest first
    $stmt = $productsDB->prepare("SELECT id, name, description, price, stock_quantity, image_url FROM products ORDER BY id DESC");
    $stmt->execute();
    $products = $stmt->fetchAll(); // Fetch products as an array
} catch (PDOException $e) {
    // Show error if something goes wrong with the query
    die("Database Error: " . $e->getMessage());
}

// Include the website header
require_once dirname(__DIR__) . '/public/templates/header.php'; 
?>

<!-- Page title -->
<h2 class="text-center mb-4">Our Products</h2>

<!-- Product listing section -->
<div class="container">
    <div class="row">
        <!-- If products are available, show them -->
        <?php if (!empty($products)): ?>
            <?php foreach ($products as $product): ?>
                <div class="col-md-4 col-sm-6 mb-4">
                    <div class="card product-card shadow-sm border-0">
                        <!-- Product image -->
                        <img src="<?= htmlspecialchars($product['image_url']); ?>" class="card-img-top" alt="<?= htmlspecialchars($product['name']); ?>">

                        <!-- Product details -->
                        <div class="card-body text-center">
                            <h6 class="card-title"><?= htmlspecialchars($product['name']); ?></h6>
                            <p class="card-text text-muted"><?= htmlspecialchars($product['description']); ?></p>
                            <p class="price">$<?= number_format($product['price'], 2); ?></p>
                            <p class="text-muted">Stock: <?= (int)$product['stock_quantity']; ?></p>

                            <!-- If product is in stock, show add to cart form -->
                            <?php if ($product['stock_quantity'] > 0): ?>
                                <form method="post" action="/Project_1_Online_Store/sessions/add_to_cart.php">
                                    <!-- Hidden inputs for product data -->
                                    <input type="hidden" name="product_id" value="<?= $product['id']; ?>">
                                    <input type="hidden" name="product_name" value="<?= $product['name']; ?>">
                                    <input type="hidden" name="product_price" value="<?= $product['price']; ?>">
                                    <!-- Quantity input -->
                                    <input type="number" name="quantity" value="1" min="1" max="<?= $product['stock_quantity']; ?>" class="form-control mb-2" style="width: 80px; margin: 0 auto;">

                                    <!-- Submit button -->
                                    <button type="submit" class="btn btn-warning btn-sm">Add to Cart</button>
                                </form>
                            <?php else: ?>
                                <!-- If out of stock, show disabled button -->
                                <button class="btn btn-secondary btn-sm" disabled>Out of Stock</button>
                            <?php endif; ?>
                        </div>
                    </div>
                </div>
            <?php endforeach; ?>
        <?php else: ?>
            <!-- Show message if no products found -->
            <div class="col-12 text-center">
                <p class="alert alert-warning">No products available at the moment.</p>
            </div>
        <?php endif; ?>
    </div>
</div>

<!-- Back to home link -->
<a href="/Project_1_Online_Store/public/index.php" class="back-link">Back to Home</a>

<!-- Extra space before footer -->
<div class="pb-5"></div>

<!-- Add footer -->
<?php require_once dirname(__DIR__) . '/public/templates/footer.php'; ?>

