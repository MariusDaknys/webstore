<?php
// Connect to the database
require_once __DIR__ . "/../src/DBconnection.php"; 

try {
    // Test the connection
    $stmt = $connection->query("SELECT 1");
    echo "Database connection successful!";
} catch (PDOException $e) {
    // Show error if connection fails
    echo "Error: " . $e->getMessage();
}