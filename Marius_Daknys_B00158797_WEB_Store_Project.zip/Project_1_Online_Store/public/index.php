

<?php require_once dirname(__DIR__) . '/public/templates/header.php'; // Add header layout ?>
<section class="hero-section position-relative text-center text-white">
    <!-- Hero image section -->
    <div class="position-relative w-100" style="max-height: 500px; overflow: hidden;">
        <img src="/Project_1_Online_Store/public/images/hero5.jpg" class="img-fluid w-100" alt="Hero Image" style="height: 100%; object-fit: cover;">
        <div class="position-absolute top-50 start-50 translate-middle p-4">
            <h1 class="fw-bold display-3">T-Shirt World</h1>
            <p class="fs-4">Find Your Perfect Style</p>
            <a href="/Project_1_Online_Store/public/products.php" class="btn btn-warning text-white fw-bold px-5 py-3">Shop Now</a>
        </div>
    </div>
</section>

<section class="py-5 bg-light">
    <div class="container">
        <div class="row align-items-center">
            <!-- Left side: About Us image -->
            <div class="col-md-6">
                <img src="/Project_1_Online_Store/public/images/aboutpic.jpg" class="img-fluid rounded shadow" alt="About Us">
            </div>

            <!-- Right side: About Us text content -->
            <div class="col-md-6 d-flex flex-column justify-content-center">
                <h2 class="fw-bold mb-3">About Us</h2>
                <p class="text-muted">
                    At <strong>T-Shirt World</strong>, Lorem ipsum dolor sit amet consectetur adipisicing elit. Non, deserunt? Praesentium similique, dolor veniam excepturi ipsa distinctio animi minus libero.
                </p>
                <h4 class="mt-3 fw-bold">What We Do</h4>
                <p class="text-muted">
                    Lorem ipsum dolor sit amet consectetur adipisicing elit. Mollitia itaque officia eius reprehenderit necessitatibus dolores voluptates eveniet! Porro, assumenda excepturi.
                </p>
                <div class="mt-4">
                    <a href="about_us.php" class="btn btn-warning text-white fw-bold px-4 py-2">Learn More</a>
                </div>
            </div>
        </div>
    </div>
</section>

<section class="bg-light py-5">
    <div class="container text-center">
        <h2 class="fw-bold mb-4">Why Choose Us?</h2>
        <div class="row">
            <!-- Feature 1: Premium Quality -->
            <div class="col-md-4">
                <img src="/Project_1_Online_Store/public/images/high-quality.png" class="custom-img rounded mb-3" alt="Premium Quality">
                <h5 class="mt-3">Premium Quality</h5>
                <p>Made from high-quality breathable fabric, perfect for summer.</p>
            </div>

            <!-- Feature 2: Eco-Friendly -->
            <div class="col-md-4">
                <img src="/Project_1_Online_Store/public/images/recycle.png" class="custom-img rounded mb-3" alt="Eco-Friendly">
                <h5 class="mt-3">Eco-Friendly</h5>
                <p>We use sustainable materials and ethical production methods.</p>
            </div>

            <!-- Feature 3: Comfort & Style -->
            <div class="col-md-4">
                <img src="/Project_1_Online_Store/public/images/light.png" class="custom-img rounded mb-3" alt="Comfort & Style">
                <h5 class="mt-3">Comfort & Style</h5>
                <p>Designed to keep you comfortable while making a fashion statement.</p>
            </div>
        </div>
    </div>
</section>

<?php require_once dirname(__DIR__) . '/public/templates/footer.php'; // Add footer layout ?>
