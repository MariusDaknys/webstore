<?php
session_start(); 
// Include config and database connection
require_once __DIR__ . "/../config/config.php";
require_once __DIR__ . "/../src/DBconnection.php";
require_once __DIR__ . "/../sessions/functions.php";


$error = ""; // Store error messages

// Check if form is submitted
if ($_SERVER["REQUEST_METHOD"] === "POST") {
    // Clean up inputs
    $usernameInput = escape(($_POST['user_name'] ?? ''));
    $passwordInput = escape($_POST['user_password'] ?? '');

    // Check if inputs are filled
    if (empty($usernameInput) || empty($passwordInput)) {
        $error = "Both fields are required.";
    }
    // Check username length
    elseif (strlen($usernameInput) < 3) {
        $error = "Username must be at least 3 characters.";
    }
    // Check password length
    elseif (strlen($passwordInput) < 6) {
        $error = "Password must be at least 6 characters.";
    }
    // If all inputs are valid
    else {
        try {
            // Find user in database
            $stmt = $usersDB->prepare("SELECT password, user_type FROM users WHERE username = ?");
            $stmt->execute([$usernameInput]);
            $user = $stmt->fetch(PDO::FETCH_ASSOC);

            // If user not found
            if (!$user) {
                $error = "No user found with that username.";
            }
            // If password doesn't match
            elseif (!password_verify($passwordInput, $user['password'])) {
                $error = "Incorrect password.";
            }
            // If login successful
            else {
                $_SESSION['Username'] = $usernameInput;
                $_SESSION['Active'] = true;
                $_SESSION['UserType'] = $user['user_type'];

                header("location: index.php"); // Redirect to homepage
                exit();
            }
        } catch (PDOException $e) {
            $error = "Database Error: " . $e->getMessage();
        }
    }
}
?>

<?php require_once dirname(__DIR__) . '/public/templates/header.php'; //Include header ?>

<div class="user-registration">
    <div class="container">
        <div class="row justify-content-center">
            <div class="col-md-8 col-lg-6">
                <div class="registration-box">
                    <h2 class="text-center text-highlight">Login Page</h2>

                    <!-- Show error if exists -->
                    <?php if (!empty($error)): ?>
                        <div class="alert alert-danger"><?= htmlspecialchars($error); ?></div>
                    <?php endif; ?>

                    <!-- Login form -->
                    <form method="post">
                        <!-- Username -->
                        <div class="mb-3">
                            <label for="user_name">Username</label>
                            <input type="text" name="user_name" id="user_name" class="form-field" required>
                        </div>

                        <!-- Password -->
                        <div class="mb-3">
                            <label for="user_password">Password</label>
                            <input type="password" name="user_password" id="user_password" class="form-field" required>
                        </div>

                        <!-- Remember me checkbox -->
                        <div class="mb-3">
                            <label>
                                <input type="checkbox" name="remember_me" value="1"> Remember me
                            </label>
                        </div>

                        <!-- Submit button -->
                        <button type="submit" name="Submit" class="submit-btn">Login</button>

                        <!-- Back to home -->
                        <a href="index.php" class="back-link">Back to Home</a>
                    </form>
                </div>
            </div>
        </div>
    </div>
</div>

<?php require_once dirname(__DIR__) . '/public/templates/footer.php'; // Include footer ?>
