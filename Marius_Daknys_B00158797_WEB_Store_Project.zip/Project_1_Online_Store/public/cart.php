<?php
session_start(); // Start the session to store or access user data like the cart

// Make sure the cart session exists if not create empty cart
if (!isset($_SESSION['cart'])) {
    $_SESSION['cart'] = [];
}

// Include the header layout 
require_once __DIR__ . "/../public/templates/header.php";

// Grab the cart from the session  if not set we default ot empty
$cart = $_SESSION['cart'] ?? [];
$totalPrice = 0; // use this to add total
?>

<div class="container mt-5">
    <h2 class="text-center mb-4">Shopping Cart</h2>

    <!-- If the cart is empty, show a message -->
    <?php if (empty($cart)): ?>
        <p class="text-center alert alert-warning">Your cart is empty.</p>

    <!-- If the cart has items, show them in table -->
    <?php else: ?>
        <div class="table-responsive">
            <table class="table table-striped table-bordered shadow-sm">
                <thead class="table-dark">
                    <tr>
                        <th>Product</th>
                        <th>Price</th>
                        <th>Quantity</th>
                        <th>Total</th>
                        <th>Action</th>
                    </tr>
                </thead>
                <tbody>
                    <!-- Loop through each item in the cart and display all -->
                    <?php foreach ($cart as $id => $item): ?>
                        <?php 
                            $subtotal = $item['price'] * $item['quantity']; // Calculate total for each item
                            $totalPrice += $subtotal; // Add to the final cart total
                        ?>
                        <tr>
                            <td><?= htmlspecialchars($item['name']); ?></td>
                            <td>€<?= number_format($item['price'], 2); ?></td>
                            <td><?= (int)$item['quantity']; ?></td>
                            <td>€<?= number_format($subtotal, 2); ?></td>
                            <td>
                                <!-- Form to remove item from cart-->
                                <form method="post" action="/Project_1_Online_Store/admin/remove_from_cart.php" style="display:inline;">
                                    <input type="hidden" name="product_id" value="<?= $id; ?>">
                                    <button type="submit" class="btn btn-danger btn-sm">Remove</button>
                                </form>
                            </td>
                        </tr>
                    <?php endforeach; ?>
                </tbody>
            </table>
        </div>

        <!-- Show total price and a button to go to the checkout page -->
        <div class="d-flex justify-content-between align-items-center mt-4">
            <h3 class="text-primary">Total: €<?= number_format($totalPrice, 2); ?></h3>
            <a href="index.php" class="btn btn-success btn-lg">Proceed to Checkout</a>
        </div>
    <?php endif; ?>
</div>

<!-- Add some space before the footer  -->
<div class="py-5"></div>

<!-- The footer for layout -->
<?php require_once __DIR__ . "/../public/templates/footer.php"; ?>
