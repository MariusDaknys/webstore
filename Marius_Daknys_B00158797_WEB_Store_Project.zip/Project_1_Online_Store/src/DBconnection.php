<?php
require_once __DIR__ . '/../config/config.php';

try {
    // Connect to users database
    $usersDB = new PDO($dsn, $username, $password, $options);
    $usersDB->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);

    // Connect to products database
    $productsDB = new PDO($dsn_product, $username, $password, $options);
    $productsDB->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);

} catch (PDOException $error) {
    die("Database connection failed: " . $error->getMessage());
}
?>
