<?php

// Database connection settings
$host       = "localhost";
$username   = "root";
$password   = "";

// database names
$dbname     = "UserTable";
$products_db = "products";

// DSN strings for connecting with PDO
$dsn        = "mysql:host=$host;dbname=$dbname";
$dsn_product = "mysql:host=$host;dbname=$products_db;charset=utf8mb4";

// PDO options (error mode and fetch mode)
$options = array(
    PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION,           // Throw exceptions on errors
    PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC       // Return results as associative arrays
);
?>
