<?php
session_start();
require_once __DIR__ . "/../sessions/functions.php";
require_once __DIR__ . "/../src/DBconnection.php";
require_once __DIR__ . "/../sessions/ProductManager.php";

// Check if the user is logged in and is an admin
if (!isset($_SESSION['Active']) || $_SESSION['Active'] !== true || $_SESSION['UserType'] !== 'admin') {
    header("location: ../login.php");
    exit();
}

// Set up ProductManager
$productManager = new ProductManager($productsDB);

// Check if product ID is provided
$product_id = $_GET['id'] ?? null;
if (!$product_id || !is_numeric($product_id)) {
    die("Product ID is missing.");
}

$error = "";
$successMessage = "";

// Fetch product details using ProductManager
$product = $productManager->getProductById($product_id);

if (!$product) {
    die("Product not found.");
}

// Handle form submission
if ($_SERVER["REQUEST_METHOD"] === "POST") {
    $updatedName = escape($_POST['product_name']);
    $updatedDescription = escape($_POST['product_description']);
    $updatedPrice = escape($_POST['product_price']);
    $updatedStock = escape($_POST['product_stock_quantity']);
    $imageFileName = $product['image_url']; // Keep existing image by default

    // Validate inputs
    if (empty($updatedName) || empty($updatedDescription) || empty($updatedPrice) || empty($updatedStock)) {
        $error = "All fields are required.";
    } elseif (!is_numeric($updatedPrice) || $updatedPrice <= 0) {
        $error = "Invalid price.";
    } elseif (!is_numeric($updatedStock) || $updatedStock < 0) {
        $error = "Stock must be a non-negative number.";
    } else {
        // Handle Image Upload
        if (!empty($_FILES['product_image']['name'])) {
            $uploadDir = __DIR__ . "/../public/uploads/";
            if (!file_exists($uploadDir)) {
                mkdir($uploadDir, 0777, true);
            }

            $imageFileNameOnly = time() . "_" . basename($_FILES["product_image"]["name"]);
            $targetFilePath = $uploadDir . $imageFileNameOnly;
            $dbImagePath = "/Project_1_Online_Store/public/uploads/" . $imageFileNameOnly;
            $imageFileType = strtolower(pathinfo($targetFilePath, PATHINFO_EXTENSION));

            $allowedTypes = ['jpg', 'jpeg', 'png', 'gif'];
            if (!in_array($imageFileType, $allowedTypes)) {
                $error = "Invalid image format. Allowed formats: JPG, JPEG, PNG, GIF.";
            } elseif (!move_uploaded_file($_FILES["product_image"]["tmp_name"], $targetFilePath)) {
                $error = "Image upload failed.";
            } else {
                $imageFileName = $dbImagePath; // Save correct path
            }
        }
    }

    // Update product if no error
    if (empty($error)) {
        $success = $productManager->updateProduct(
            $product_id,
            $updatedName,
            $updatedDescription,
            $updatedPrice,
            $updatedStock,
            $imageFileName
        );

        if ($success) {
            $successMessage = "Product updated successfully!";
            $product = $productManager->getProductById($product_id); // Refresh product after update
        } else {
            $error = "Failed to update product.";
        }
    }
}

require_once dirname(__DIR__) . '/public/templates/header.php';
?>

<div class="container1 mt-5">
<h2 class="text-center text-black">Edit Product</h2>
    <div class="product-add">
    <div class="container">
        <div class="row justify-content-center">
            <div class="col-md-8 col-lg-6">
                <div class="product-box">

                    <!-- Show Success or Error Messages -->
                    <?php if (!empty($error)): ?>
                        <div class="alert alert-danger"><?php echo $error; ?></div>
                    <?php endif; ?>
                    <?php if (!empty($successMessage)): ?>
                        <div class="alert alert-success"><?php echo $successMessage; ?></div>
                    <?php endif; ?>

                    <form method="post" enctype="multipart/form-data">
                        <div class="mb-3">
                            <label for="product_name">Product Name</label>
                            <input type="text" name="product_name" id="product_name" class="form-field" value="<?= escape($product['name']); ?>" required>
                        </div>
                        <div class="mb-3">
                            <label for="product_description">Description</label>
                            <textarea name="product_description" id="product_description" class="form-field" required><?= escape($product['description']); ?></textarea>
                        </div>
                        <div class="mb-3">
                            <label for="product_price">Price ($)</label>
                            <input type="number" step="0.01" name="product_price" id="product_price" class="form-field" value="<?= escape($product['price']); ?>" required>
                        </div>
                        <div class="mb-3">
                            <label for="product_stock_quantity">Stock Quantity</label>
                            <input type="number" name="product_stock_quantity" id="product_stock_quantity" class="form-field" value="<?= escape($product['stock_quantity']); ?>" required>
                        </div>
                        <div class="mb-3">
                            <label for="product_image">Update Product Image (Leave empty to keep current)</label>
                            <input type="file" name="product_image" id="product_image" class="form-control" accept="image/*">
                        </div>

                        <!-- Show current image if exists -->
                        <?php if (!empty($product['image_url'])): ?>
                            <div class="mb-3">
                                <label>Current Image:</label><br>
                                <img src="<?= htmlspecialchars($product['image_url']); ?>" alt="Product Image" width="150">
                            </div>
                        <?php endif; ?>

                        <button type="submit" class="submit-btn">Update Product</button>
                    </form>
                    <!-- Add spacing at the bottom -->
                        <div class="pb-5"></div>

                    <div class="text-center mt-3">
                        <a href="/Project_1_Online_Store/public/products.php" class="back-link">Back to Products</a>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
                    <div class="pb-5"></div>
<?php require_once dirname(__DIR__) . '/public/templates/footer.php'; ?>
