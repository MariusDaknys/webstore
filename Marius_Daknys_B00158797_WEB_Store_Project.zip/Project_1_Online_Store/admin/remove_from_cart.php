<?php
session_start();

// Enable debugging
error_reporting(E_ALL);
ini_set('display_errors', 1);

// Check if request is POST and `product_id` is set
if ($_SERVER["REQUEST_METHOD"] === "POST" && isset($_POST['product_id'])) {
    $productId = $_POST['product_id'];

    //  Check if product exists in the cart before removing
    if (isset($_SESSION['cart'][$productId])) {
        unset($_SESSION['cart'][$productId]); // Remove the product
    }

    // Redirect back to cart page
    header("Location: /Project_1_Online_Store/public/cart.php");
    exit();
} else {
    //  Redirect to home page if accessed directly
    header("Location: /Project_1_Online_Store/public/index.php");
    exit();
}


