<?php
session_start();
// Include the database connection
require_once __DIR__ . "/../src/DBconnection.php"; 
require_once __DIR__ . "/../sessions/functions.php";

// Check if user is logged in and is an admin
if (!isset($_SESSION['Active']) || $_SESSION['Active'] !== true || $_SESSION['UserType'] !== 'admin') {
    header("location: login.php");
    exit();
}

// Get the user ID from the URL
$user_id = $_GET['id'] ?? null;

// Validate user ID
if (!$user_id || !is_numeric($user_id)) {
    die("Invalid user ID.");
}

// Fetch user details from the database
try {
    $stmt = $usersDB->prepare("SELECT * FROM users WHERE id = ?");
    $stmt->execute([$user_id]);
    $user = $stmt->fetch();

    // If user not found, stop execution
    if (!$user) {
        die("User not found in database.");
    }
} catch (PDOException $e) {
    die("Database Error: " . $e->getMessage());
}

// Initialize error and success message variables
$error = "";
$successMessage = "";

// Handle form submission
if ($_SERVER["REQUEST_METHOD"] === "POST") {
    // Get updated values from the form
    $updatedUsername = escape($_POST['username']);
    $updatedEmail = escape($_POST['email']);
    $updatedAge = escape($_POST['age']);
    $updatedAddress = escape($_POST['address']);
    $updatedGender = escape($_POST['gender']);
    $updatedUserType = escape($_POST['user_type']);

    // Validate input
    if (empty($updatedUsername) || empty($updatedEmail) || empty($updatedAge) || empty($updatedAddress) || empty($updatedGender) || empty($updatedUserType)) {
        $error = "All fields are required.";
    } elseif (!filter_var($updatedEmail, FILTER_VALIDATE_EMAIL)) {
        $error = "Invalid email format.";
    } elseif (!is_numeric($updatedAge) || $updatedAge < 0 || $updatedAge > 120) {
        $error = "Invalid age. Must be between 0 and 120.";
    } else {
        try {
            // Update user data in the database
            $stmt = $usersDB->prepare("UPDATE users SET username=?, email=?, age=?, address=?, gender=?, user_type=? WHERE id=?");
            $stmt->execute([
                $updatedUsername,
                $updatedEmail,
                $updatedAge,
                $updatedAddress,
                $updatedGender,
                $updatedUserType,
                $user_id
            ]);

            // Set success message
            $successMessage = "User updated successfully.";

            // Refresh user data
            $stmt = $usersDB->prepare("SELECT * FROM users WHERE id = ?");
            $stmt->execute([$user_id]);
            $user = $stmt->fetch();
        } catch (PDOException $e) {
            $error = "Database Error: " . $e->getMessage();
        }
    }
}

// Include the page header
require_once dirname(__DIR__) . '/public/templates/header.php';
?>

<!-- Page Content -->
<div class="product-add">
    <div class="container">
        <div class="row justify-content-center">
            <div class="col-md-8 col-lg-6">
                <div class="product-box">
                    <h2 class="text-center text-highlight">Edit User</h2>

                    <!-- Display error message -->
                    <?php if (!empty($error)): ?>
                        <div class="alert alert-danger"><?= escape($error); ?></div>
                    <?php endif; ?>

                    <!-- Display success message -->
                    <?php if (!empty($successMessage)): ?>
                        <div class="alert alert-success"><?= escape($successMessage); ?></div>
                    <?php endif; ?>

                    <!-- Edit user form -->
                    <form method="post">
                        <div class="mb-3">
                            <label for="username">Username</label>
                            <input type="text" name="username" id="username" class="form-field" 
                                   value="<?= escape($user['username'] ?? ''); ?>" required>
                        </div>

                        <div class="mb-3">
                            <label for="email">Email Address</label>
                            <input type="email" name="email" id="email" class="form-field" 
                                   value="<?= escape($user['email'] ?? ''); ?>" required>
                        </div>

                        <div class="mb-3">
                            <label for="age">Age</label>
                            <input type="number" name="age" id="age" class="form-field" 
                                   value="<?= escape($user['age'] ?? ''); ?>" required>
                        </div>

                        <div class="mb-3">
                            <label for="address">Address</label>
                            <input type="text" name="address" id="address" class="form-field" 
                                   value="<?= escape($user['address'] ?? ''); ?>" required>
                        </div>

                        <div class="mb-3">
                            <label for="gender">Gender</label>
                            <select name="gender" id="gender" class="form-field">
                                <option value="male" <?= (isset($user['gender']) && $user['gender'] === 'male') ? 'selected' : ''; ?>>Male</option>
                                <option value="female" <?= (isset($user['gender']) && $user['gender'] === 'female') ? 'selected' : ''; ?>>Female</option>
                                <option value="other" <?= (isset($user['gender']) && $user['gender'] === 'other') ? 'selected' : ''; ?>>Other</option>
                            </select>
                        </div>

                        <div class="mb-3">
                            <label for="user_type">User Type</label>
                            <select name="user_type" id="user_type" class="form-field">
                                <option value="customer" <?= (isset($user['user_type']) && $user['user_type'] === 'customer') ? 'selected' : ''; ?>>Customer</option>
                                <option value="admin" <?= (isset($user['user_type']) && $user['user_type'] === 'admin') ? 'selected' : ''; ?>>Admin</option>
                            </select>
                        </div>

                        <!-- Submit button -->
                        <button type="submit" class="submit-btn btn btn-warning">Update User</button>
                    </form>

                    <!-- Back link -->
                    <div class="text-center mt-3">
                        <a href="edit_users.php" class="back-link">Back to Users</a>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

<!-- Extra bottom padding -->
<div class="pb-5"></div>

<!-- Include the page footer -->
<?php require_once dirname(__DIR__) . '/public/templates/footer.php'; ?>
