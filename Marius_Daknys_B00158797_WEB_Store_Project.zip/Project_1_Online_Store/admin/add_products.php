<?php
session_start();
require_once __DIR__ . "/../sessions/functions.php";
require_once __DIR__ . '/../src/DBconnection.php';
require_once __DIR__ . '/../sessions/ProductManager.php';

// Check if the user is logged in and is an admin
if (!isset($_SESSION['Active']) || $_SESSION['Active'] !== true || $_SESSION['UserType'] !== 'admin') {
    header("location: ../login.php");
    exit();
}

$productManager = new ProductManager($productsDB);

$error = "";
$successMessage = "";

// Handle form submission
if ($_SERVER["REQUEST_METHOD"] === "POST") {
    $productName = escape($_POST['product_name'] ?? '');
    $productDescription = escape($_POST['product_description'] ?? '');
    $productPrice = escape($_POST['product_price'] ?? '');
    $productStock = escape($_POST['product_stock_quantity'] ?? '');

    // Handle image upload
    $imagePath = "";
    if (isset($_FILES['product_image']) && $_FILES['product_image']['error'] === UPLOAD_ERR_OK) {
        $uploadDir = __DIR__ . '/../public/images/';
        $fileName = basename($_FILES['product_image']['name']);
        $imagePath = "/Project_1_Online_Store/public/images/" . $fileName;
        $uploadFile = $uploadDir . $fileName;

        if (!move_uploaded_file($_FILES['product_image']['tmp_name'], $uploadFile)) {
            $error = "Error uploading image!";
        }
    } else {
        $error = "Please select an image file.";
    }

    // Only continue if no upload error
    if (empty($error)) {
        //  validation
        if (
            empty($productName) ||
            empty($productDescription) ||
            empty($productPrice) ||
            empty($productStock) ||
            empty($imagePath)
        ) {
            $error = "All fields are required, including an image.";
        } elseif (strlen($productName) < 3) {
            $error = "Product name must be at least 3 characters.";
        } elseif (!is_numeric($productPrice) || $productPrice <= 0) {
            $error = "Invalid price. Must be a positive number.";
        } elseif (!is_numeric($productStock) || $productStock < 0) {
            $error = "Stock must be a non-negative number.";
        } else {
            try {
                if ($productManager->productExists($productName)) {
                    $error = "Product with this name already exists.";
                } else {
                    $productManager->addProduct($productName, $productDescription, $productPrice, $productStock, $imagePath);
                    $successMessage = "Product added successfully!";
                }
            } catch (PDOException $e) {
                $error = "Database Error: " . $e->getMessage();
            }
        }
    }
}
?>

<?php require_once dirname(__DIR__) . '/public/templates/header.php'; ?>

<div class="product-add">
    <div class="container">
        <div class="row justify-content-center">
            <div class="col-md-8 col-lg-6">
                <div class="product-box">
                    <h2 class="text-center text-highlight">Add Product</h2>

                    <!-- Show Success or Error Messages -->
                    <?php if (!empty($error)): ?>
                        <div class="alert alert-danger"><?php echo $error; ?></div>
                    <?php endif; ?>
                    <?php if (!empty($successMessage)): ?>
                        <div class="alert alert-success"><?php echo $successMessage; ?></div>
                    <?php endif; ?>

                    <form method="post" enctype="multipart/form-data">
                        <div class="mb-3">
                            <label for="product_name">Product Name</label>
                            <input type="text" name="product_name" id="product_name" class="form-field" required>
                        </div>
                        <div class="mb-3">
                            <label for="product_description">Description</label>
                            <textarea name="product_description" id="product_description" class="form-field" required></textarea>
                        </div>
                        <div class="mb-3">
                            <label for="product_price">Price ($)</label>
                            <input type="number" step="0.01" name="product_price" id="product_price" class="form-field" required>
                        </div>
                        <div class="mb-3">
                            <label for="product_stock_quantity">Stock Quantity</label>
                            <input type="number" name="product_stock_quantity" id="product_stock_quantity" class="form-field" required>
                        </div>
                        <div class="mb-3">
                            <label for="product_image">Product Image</label>
                            <input type="file" name="product_image" id="product_image" class="form-control" accept="image/*" required>
                        </div>
                        <button type="submit" class="submit-btn">Add Product</button>
                    </form>

                    <div class="text-center mt-3">
                        <a href="/Project_1_Online_Store/public/products.php" class="back-link">Back to Products</a>
                    </div>
                    <div class="pb-5"></div>
                </div>
            </div>
        </div>
    </div>
</div>

<?php require_once dirname(__DIR__) . '/public/templates/footer.php'; ?>
