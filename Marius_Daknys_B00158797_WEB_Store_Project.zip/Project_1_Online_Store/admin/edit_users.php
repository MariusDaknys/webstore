<?php
// Start session
session_start();

// Include configuration, database connection, and UserManager class
require_once __DIR__ . '/../config/config.php';
require_once __DIR__ . '/../src/DBconnection.php';
require_once __DIR__ . '/../sessions/UserManager.php';
require_once __DIR__ . "/../sessions/functions.php";

// Check if the user is logged in and is an admin
if (!isset($_SESSION['Active']) || $_SESSION['Active'] !== true || $_SESSION['UserType'] !== 'admin') {
    header("location: ../login.php");
    exit();
}

// Create UserManager instance
$userManager = new UserManager($usersDB);

// Initialize error message variable
$error = "";

// Handle user deletion using POST method
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['delete_user_id']) && is_numeric($_POST['delete_user_id'])) {
    $user_id = $_POST['delete_user_id'];

    try {
        // Get user by ID
        $user = $userManager->getUserById($user_id);

        if ($user) {
            // Delete user
            $userManager->deleteUser($user_id);

            // Redirect with success message
            header("Location: edit_users.php?success=User+Deleted+Successfully");
            exit();
        } else {
            $error = "User not found.";
        }
    } catch (PDOException $e) {
        $error = "Database Error: " . $e->getMessage();
    }
}

// Fetch all users from the database
try {
    $users = $userManager->getAllUsers();
} catch (PDOException $e) {
    die("Database Error: " . $e->getMessage());
}

// Include header template
require_once __DIR__ . '/../public/templates/header.php';
?>

<div class="container mt-5">
    <h2 class="text-center text-highlight">Manage Users</h2>

    <?php if (isset($_GET['success'])): ?>
        <div class="alert alert-success"><?= escape($_GET['success']); ?></div>
    <?php endif; ?>

    <?php if (!empty($error)): ?>
        <div class="alert alert-danger"><?= escape($error); ?></div>
    <?php endif; ?>

    <!-- User table -->
    <table class="table table-white table-hover mt-4">
        <thead>
            <tr>
                <th>ID</th>
                <th>Username</th>
                <th>Email</th>
                <th>User Type</th>
                <th>Actions</th>
            </tr>
        </thead>
        <tbody>
            <?php foreach ($users as $user): ?>
                <tr>
                    <td><?= escape($user['id']); ?></td>
                    <td><?= escape($user['username']); ?></td>
                    <td><?= escape($user['email']); ?></td>
                    <td><?= escape($user['user_type']); ?></td>
                    <td>
                        <!-- Edit button -->
                        <a href="update_users.php?id=<?= $user['id']; ?>" class="btn btn-warning btn-sm">Edit</a>

                        <!-- Delete form using POST -->
                        <form method="post" action="edit_users.php" style="display:inline;" onsubmit="return confirm('Are you sure you want to delete this user?');">
                            <input type="hidden" name="delete_user_id" value="<?= $user['id']; ?>">
                            <button type="submit" class="btn btn-danger btn-sm">Delete</button>
                        </form>
                    </td>
                </tr>
            <?php endforeach; ?>
        </tbody>
    </table>

    <!-- Back to home -->
    <div class="text-center mt-4">
        <a href="/Project_1_Online_Store/public/index.php" class="back-link">Back to Home</a>
    </div>
</div>

<div class="pb-5"></div>

<?php require_once __DIR__ . '/../public/templates/footer.php'; ?>
