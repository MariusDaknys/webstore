<?php
session_start();

// Include the database connection
require_once __DIR__ . "/../src/DBconnection.php";
require_once __DIR__ . "/../sessions/functions.php";

// Check if the user is logged in and is an admin
if (!isset($_SESSION['Active']) || $_SESSION['Active'] !== true || $_SESSION['UserType'] !== 'admin') {
    header("location: ../login.php");
    exit();
}
// Fetch all products from the database
try {
    $stmt = $productsDB->query("SELECT * FROM products ORDER BY id DESC");
    $products = $stmt->fetchAll();
} catch (PDOException $e) {
    // Handle database errors
    die("Database Error: " . $e->getMessage());
}

// Handle product deletion when form is submitted
if ($_SERVER["REQUEST_METHOD"] === "POST" && isset($_POST['delete_product_id'])) {
    $productIdToDelete = $_POST['delete_product_id'];

    try {
        // Get the image URL of the product to be deleted
        $stmt = $productsDB->prepare("SELECT image_url FROM products WHERE id = ?");
        $stmt->execute([$productIdToDelete]);
        $product = $stmt->fetch();

        // Delete the product record from the database
        $stmt = $productsDB->prepare("DELETE FROM products WHERE id = ?");
        $stmt->execute([$productIdToDelete]);

        // Delete the image file from the server if it exists
        if ($product && file_exists(__DIR__ . "/../public/uploads/" . basename($product['image_url']))) {
            unlink(__DIR__ . "/../public/uploads/" . basename($product['image_url']));
        }

        // Redirect back to the edit page with a success message
        header("Location: edit_products.php?success=Product deleted successfully");
        exit();
    } catch (PDOException $e) {
        // Handle any database error
        die("Database Error: " . $e->getMessage());
    }
}

// page header
require_once dirname(__DIR__) . '/public/templates/header.php';
?>

<div class="container mt-5">
    <h2 class="text-center text-highlight">Edit Products</h2>

    <!-- Display success message if product is deleted -->
    <?php if (isset($_GET['success'])): ?>
        <div class="alert alert-success"><?= htmlspecialchars($_GET['success']); ?></div>
    <?php endif; ?>

    <!-- Products table -->
    <table class="table table-white table-hover mt-4">
        <thead>
            <tr>
                <th>ID</th>
                <th>Image</th>
                <th>Name</th>
                <th>Price</th>
                <th>Stock</th>
                <th>Action</th>
            </tr>
        </thead>
        <tbody>
            <!-- Loop through each product and display its details -->
            <?php foreach ($products as $product): ?>
                <tr>
                    <td><?= escape($product['id']); ?></td>
                    <td>
                        <img src="<?= escape($product['image_url']); ?>" width="50" alt="Product Image">
                    </td>
                    <td><?= escape($product['name']); ?></td>
                    <td>$<?= number_format($product['price'], 2); ?></td>
                    <td><?= escape($product['stock_quantity']); ?></td>
                    <td>
                        <!-- Edit button -->
                        <a href="edit_page_form.php?id=<?= $product['id']; ?>" class="btn btn-warning btn-sm">Edit</a>

                        <!-- Delete form -->
                        <form method="post" class="d-inline">
                            <input type="hidden" name="delete_product_id" value="<?= $product['id']; ?>">
                            <button type="submit" class="btn btn-danger btn-sm" onclick="return confirm('Are you sure you want to delete this product?');">
                                Delete
                            </button>
                        </form>
                    </td>
                </tr>
            <?php endforeach; ?>
        </tbody>
    </table>
</div>

<!-- Link to go back to the products page -->
<div class="text-center mt-3">
    <a href="/Project_1_Online_Store/public/products.php" class="back-link">Back to Products</a>
</div>
<!-- Add spacing at the bottom -->
<div class="pb-5"></div>
<!-- Include the page footer -->
<?php require_once dirname(__DIR__) . '/public/templates/footer.php'; ?>
