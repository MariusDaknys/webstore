Marius Daknys
B00158797
Web Applications Assignment 


Online Store Project
T-Shirt World

Project Description:
This is a basic online store website built for my Web Applications project.
It uses PHP, MySQL, and simple classes to manage users, products, and admin features.
The system allows users to register, log in, browse products, and manage shopping carts.
Admins can add, edit, or delete products and manage users.

Technologies Used:
- PHP (Custom structure, no frameworks)
- MySQL (with PDO)
- HTML & CSS (Bootstrap for layout and responsive design)
- PHP Sessions (for user login and admin control)

Main Features:
- User Registration and Login
- Admin Panel:
  - Add, edit, delete products
  - Manage users
- Product List: Open for all users to view
- Cart System: Add and remove products
- Image Uploads: Upload images for products

Folder Structure:
- /admin – Admin pages: add_products.php, edit_page_form.php, edit_products.php, edit_users.php, remove_from_cart.php, update_users.php
- /config – config.php for database settings
- /data – SQL files for products and users tables
- /install – install.php to set up the database easily
- /public – Public website files:
  - /css/ – stylesheets
  - /images/ – logo and other images
  - /templates/ – header and footer templates
  - /uploads/ – uploaded product images
  - Pages: about_us.php, cart.php, contacts.php, index.php, login.php, logout.php, products.php, Register.php.
- /sessions – Session handling and classes: add_to_cart.php, ProductManager.php, session.php, UserManager.php,functions.php
- /src – Database connection: DBconnection.php

Contribution Statement:
I wrote all of the code myself based on what we learned in Web Applications class.
No external frameworks were used. Only Bootstrap was used for basic layout and responsive design.
All PHP classes and testing files were created by me.



References:
- // Handle image upload
    $imagePath = "";
    if (isset($_FILES['product_image']) && $_FILES['product_image']['error'] === UPLOAD_ERR_OK) {
        $uploadDir = __DIR__ . '/../public/images/';
        $fileName = basename($_FILES['product_image']['name']);
        $imagePath = "/Project_1_Online_Store/public/images/" . $fileName;
        $uploadFile = $uploadDir . $fileName;

        if (!move_uploaded_file($_FILES['product_image']['tmp_name'], $uploadFile)) {
            $error = "Error uploading image!";
        }
    } else {
        $error = "Please select an image file.";
    }
This project includes PHP code to handle image uploads for product listings. It uses the built-in move_uploaded_file() function to securely store user-uploaded images in the `/public/images/` directory.

The code handles:
- Checking if an image file was uploaded without errors
- Moving the file to a permanent location
- Defining a public path for use in the application
The logic is based on examples and documentation from the official PHP manual:
PHP Manual – move_uploaded_file()https://www.php.net/manual/en/function.move-uploaded-file.php

 // Handle Image Upload
        if (!empty($_FILES['product_image']['name'])) {
            $uploadDir = __DIR__ . "/../public/uploads/";
            if (!file_exists($uploadDir)) {
                mkdir($uploadDir, 0777, true);
            }

            $imageFileNameOnly = time() . "_" . basename($_FILES["product_image"]["name"]);
            $targetFilePath = $uploadDir . $imageFileNameOnly;
            $dbImagePath = "/Project_1_Online_Store/public/uploads/" . $imageFileNameOnly;
            $imageFileType = strtolower(pathinfo($targetFilePath, PATHINFO_EXTENSION));

            $allowedTypes = ['jpg', 'jpeg', 'png', 'gif'];
            if (!in_array($imageFileType, $allowedTypes)) {
                $error = "Invalid image format. Allowed formats: JPG, JPEG, PNG, GIF.";
            } elseif (!move_uploaded_file($_FILES["product_image"]["tmp_name"], $targetFilePath)) {
                $error = "Image upload failed.";
            } else {
                $imageFileName = $dbImagePath; // Save correct path
            }
        }
    }
This project includes enhanced PHP logic for handling image uploads. Features of the upload system include:
- Creation of the upload directory if it doesn't exist
- Unique file naming using `time()` to prevent overwriting
- Validation of allowed image formats (`JPG`, `JPEG`, `PNG`, `GIF`)
- Safe movement of the uploaded file to the `/public/uploads/` directory
The implementation is based on the official PHP documentation for move_uploaded_file():
PHP Manual – move_uploaded_file()https://www.php.net/manual/en/function.move-uploaded-file.php


- Bootstrap Documentation (https://getbootstrap.com/)
- PHP Manual (https://www.php.net/manual/en/)
- W3Schools PHP Tutorials (https://www.w3schools.com/php/)
- GeeksforGeeks PHP: (https://www.geeksforgeeks.org/php-tutorial/)
- For Pictures use only (https://unsplash.com/)
- Lecture notes.



