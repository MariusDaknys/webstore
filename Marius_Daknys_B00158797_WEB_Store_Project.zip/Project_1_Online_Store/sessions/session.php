<?php
class session
{
    // Destroy all session data
    public function killSession()
    {
        // Start session if not already started
        if (session_status() === PHP_SESSION_NONE) {
            session_start();
        }

        // Clear session variables
        $_SESSION = [];

        // Remove session cookie
        if (ini_get('session.use_cookies')) {
            $params = session_get_cookie_params();
            setcookie(
                session_name(), '', time() - 42000,
                $params['path'], $params['domain'],
                $params['secure'], $params['httponly']
            );
        }

        // End the session
        session_destroy();
    }

    // Logout and redirect to login
    public function forgetSession()
    {
        $this->killSession();// Clear session
        header("Location: login.php");// Go to login page
        exit;
    }
}
?>



