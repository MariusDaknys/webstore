<?php
session_start(); // Start the session

// Create cart if it doesn't exist
if (!isset($_SESSION['cart'])) {
    $_SESSION['cart'] = [];
}

// Get product data from form
$productId = $_POST['product_id'] ?? null;
$productName = $_POST['product_name'] ?? '';
$productPrice = $_POST['product_price'] ?? 0;
$quantity = $_POST['quantity'] ?? 1;

if ($productId) {
    // If product already in cart, add quantity
    if (isset($_SESSION['cart'][$productId])) {
        $_SESSION['cart'][$productId]['quantity'] += $quantity;
    } else {
        // Else add new product to cart
        $_SESSION['cart'][$productId] = [
            'name' => $productName,
            'price' => $productPrice,
            'quantity' => $quantity
        ];
    }
}

// Go back to the previous page
header("Location: " . $_SERVER['HTTP_REFERER']);
exit();
