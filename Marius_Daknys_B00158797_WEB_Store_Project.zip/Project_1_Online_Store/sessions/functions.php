<?php
// function for security
function escape($data) {
    $data = htmlspecialchars($data, ENT_QUOTES | ENT_SUBSTITUTE, "UTF-8");
    $data = trim($data);
    $data = stripslashes($data);
    return $data;
}
// Show site logo for header
function displayLogo() {
    echo '<a class="navbar-brand d-flex align-items-center" href="/Project_1_Online_Store/public/index.php">';
    echo '<img src="/Project_1_Online_Store/public/images/logo.png" alt="T-Shirt Store" width="100px" height="auto">';
    echo '</a>';
}
//function for cart count
function getCartCount() {
    return isset($_SESSION['cart']) ? array_sum(array_column($_SESSION['cart'], 'quantity')) : 0;
}
?>