<?php
class UserManager
{
    private $db;

    // Constructor accepts a PDO database connection
    public function __construct(PDO $connection)
    {
        $this->db = $connection;
    }

    // Get all users (basic info only)
    public function getAllUsers()
    {
        $stmt = $this->db->query("SELECT id, username, email, user_type FROM users ORDER BY id DESC");
        return $stmt->fetchAll();
    }

    // Get a user by their ID
    public function getUserById($id)
    {
        $stmt = $this->db->prepare("SELECT * FROM users WHERE id = ?");
        $stmt->execute([$id]);
        return $stmt->fetch();
    }

    // Delete a user by ID
    public function deleteUser($id)
    {
        $stmt = $this->db->prepare("DELETE FROM users WHERE id = ?");
        return $stmt->execute([$id]);
    }
}
