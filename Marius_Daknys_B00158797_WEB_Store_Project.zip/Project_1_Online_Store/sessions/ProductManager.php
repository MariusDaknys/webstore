<?php
class ProductManager
{
    // Store the PDO database connection
    private $db;

    // Constructor accepts a PDO instance and assigns it to the class
    public function __construct(PDO $pdo)
    {
        $this->db = $pdo;
    }

    // Check if a product with the given name already exists in the database
    public function productExists($name)
    {
        $stmt = $this->db->prepare("SELECT id FROM products WHERE name = ?");
        $stmt->execute([$name]);
        return $stmt->rowCount() > 0;
    }

    // Add a new product to the database
    public function addProduct($name, $description, $price, $stock, $imageUrl)
    {
        try {
            $stmt = $this->db->prepare(
                "INSERT INTO products (name, description, price, stock_quantity, image_url) 
                 VALUES (?, ?, ?, ?, ?)"
            );
            return $stmt->execute([$name, $description, $price, $stock, $imageUrl]);
        } catch (PDOException $e) {
            echo "Error adding product: " . $e->getMessage();
            return false;
        }
    }
  // Get product id 
    public function getProductById($id)
{
    $stmt = $this->db->prepare("SELECT * FROM products WHERE id = ?");
    $stmt->execute([$id]);
    return $stmt->fetch();
}
// update Product
public function updateProduct($id, $name, $description, $price, $stock, $imageUrl)
{
    $stmt = $this->db->prepare(
        "UPDATE products SET name=?, description=?, price=?, stock_quantity=?, image_url=? WHERE id=?"
    );
    return $stmt->execute([$name, $description, $price, $stock, $imageUrl, $id]);
}
// Delete a product by ID
public function deleteProduct($id)
{
    $stmt = $this->db->prepare("DELETE FROM products WHERE id = ?");
    return $stmt->execute([$id]);
}

}

