-- --------------------------------------------------------
-- Host:                         127.0.0.1
-- Server version:               8.4.3 - MySQL Community Server - GPL
-- Server OS:                    Win64
-- HeidiSQL Version:             12.8.0.6908
-- --------------------------------------------------------

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET NAMES utf8 */;
/*!50503 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;


-- Dumping database structure for usertable
CREATE DATABASE IF NOT EXISTS `usertable` /*!40100 DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci */ /*!80016 DEFAULT ENCRYPTION='N' */;
USE `usertable`;

-- Dumping structure for table usertable.users
CREATE TABLE IF NOT EXISTS `users` (
  `id` int NOT NULL AUTO_INCREMENT,
  `username` varchar(50) NOT NULL,
  `email` varchar(100) NOT NULL,
  `password` varchar(255) NOT NULL,
  `age` int DEFAULT NULL,
  `address` text,
  `gender` enum('male','female','other') NOT NULL,
  `user_type` enum('customer','admin') NOT NULL DEFAULT 'customer',
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `username` (`username`),
  UNIQUE KEY `email` (`email`),
  CONSTRAINT `users_chk_1` CHECK (((`age` >= 0) and (`age` <= 120)))
) ENGINE=InnoDB AUTO_INCREMENT=29 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

-- Dumping data for table usertable.users: ~6 rows (approximately)
INSERT INTO `users` (`id`, `username`, `email`, `password`, `age`, `address`, `gender`, `user_type`, `created_at`) VALUES
	(4, 'admin', 'mar@d7fcgdsf.com', '$2y$10$NgQoxJeLeqIwxT9mKKuj9O/3AJUVUZDT9cJGFkKHO7EMEL7QQTg16', 25, 'kaunas', 'male', 'admin', '2025-03-16 17:40:51'),
	(18, 'Marius', 'mariukas.frgdfdakniukas@gmail.com', '$2y$10$6itaWT3zzn4mSpKFbKYyFe.pFQIpQX8nagIkc7WaSwj3ISMzlVWRi', 33, 'navanff', 'male', 'customer', '2025-03-29 21:15:59'),
	(21, 'Sandra', 'mariudffdskas.dakniukas@gmail.com', '$2y$10$YEQO/hkUxNXPW7vUcHKuM.BFbTsBp6aVETUi8eVFJFeGKaBReKMlC', 44, 'Cavan', 'male', 'customer', '2025-04-13 13:57:53'),
	(26, 'Fiona', 'Fiona@gmail.com', '$2y$10$0TsADxR4TVLz78m57Gq2LO8EkSHEH6/HCvCYYPFGhyDBioVHJMHmK', 20, '19 hansfield clonee dublin 16', 'male', 'customer', '2025-04-26 11:34:31'),
	(27, 'Gabriel', 'hello@gmail.com', '$2y$10$9dDw9emgILaJRZGXAJxy.uuy3iOpn01w9lShAVTpyc99XAyie0wP6', 25, 'dublin', 'male', 'admin', '2025-05-01 20:30:32'),
	(28, 'Diana', 'mariukas.dakniukas@gmail.comddd', '$2y$10$0uL6WYirCe9lHda8gO1mAe5sb3EmFkBQ/3Q90FQxZUuhp9DErhowu', 60, 'navan1', 'female', 'admin', '2025-05-02 20:32:30');

/*!40103 SET TIME_ZONE=IFNULL(@OLD_TIME_ZONE, 'system') */;
/*!40101 SET SQL_MODE=IFNULL(@OLD_SQL_MODE, '') */;
/*!40014 SET FOREIGN_KEY_CHECKS=IFNULL(@OLD_FOREIGN_KEY_CHECKS, 1) */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40111 SET SQL_NOTES=IFNULL(@OLD_SQL_NOTES, 1) */;
